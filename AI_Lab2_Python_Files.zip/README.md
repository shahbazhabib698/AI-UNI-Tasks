# AI Lab 2 — Python Files

## Files
- `lab2_percepts.py`: tests the basic classroom agent.
- `lab2_model.py`: remembers the previous target mode and avoids repeated commands.
- `lab2_check.py`: runs simple checks of expected and actual behaviour.

## Run
Use Python 3. In a terminal, run:

```bash
python lab2_percepts.py
python lab2_model.py
python lab2_check.py
```

On some Windows computers, use `py` instead of `python`.

## Policy used
- Empty room: `ECO`
- Occupied and temperature above 26°C: `COOL`
- Occupied and temperature below 20°C: `WARM`
- Otherwise: `IDLE`

At exactly 20°C and 26°C, an occupied room uses `IDLE`.
The program only simulates target modes; it does not control real hardware.
The stateful version sends a command only if the target mode differs from the previous mode.
