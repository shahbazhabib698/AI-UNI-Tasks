# AI Lab 2: Basic checks for the classroom agent

class ClassroomAgent:
    def __init__(self):
        self.previous_mode = None

    def act(self, temp, occupied):
        if not occupied:
            target = "ECO"
        elif temp > 26:
            target = "COOL"
        elif temp < 20:
            target = "WARM"
        else:
            target = "IDLE"

        send_command = target != self.previous_mode
        self.previous_mode = target
        return target, send_command


agent = ClassroomAgent()

tests = [
    ((29, True), "COOL", True),
    ((29, True), "COOL", False),
    ((20, True), "IDLE", True),
    ((26, True), "IDLE", False),
    ((19, True), "WARM", True),
    ((29, False), "ECO", True),
]

print("Test | Percept | Expected mode | Actual mode | Expected command | Actual command")
for number, (percept, expected_mode, expected_command) in enumerate(tests, 1):
    actual_mode, actual_command = agent.act(*percept)
    print(
        number, "|", percept, "|", expected_mode, "|", actual_mode,
        "|", expected_command, "|", actual_command
    )
