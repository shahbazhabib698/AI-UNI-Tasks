# AI Lab 2: Stateful classroom agent
# The agent remembers its last target mode and only sends a command
# when the target mode changes.

class ClassroomAgent:
    def __init__(self):
        self.previous_mode = None

    def act(self, temp, occupied):
        # An empty room has priority over temperature.
        if not occupied:
            target_mode = "ECO"
        elif temp > 26:
            target_mode = "COOL"
        elif temp < 20:
            target_mode = "WARM"
        else:
            target_mode = "IDLE"

        # Send a command only when the target changes.
        send_command = target_mode != self.previous_mode
        old_mode = self.previous_mode
        self.previous_mode = target_mode

        return old_mode, target_mode, send_command


agent = ClassroomAgent()

percepts = [
    (29, True),   # COOL: send command
    (29, True),   # COOL again: no command
    (20, True),   # boundary: IDLE
    (26, True),   # boundary: still IDLE
    (19, True),   # WARM
    (29, False),  # empty room: ECO
    (29, False)   # ECO again: no command
]

print("Step | Previous mode | Percept | Target | Send command?")
for step, percept in enumerate(percepts, 1):
    previous, target, send = agent.act(*percept)
    print(step, "|", previous, "|", percept, "|", target, "|", send)
