from collections import deque

# The graph from the lab manual. Neighbours stay in the given order.
graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": ["G"],
    "F": [],
    "G": []
}


def bfs(start, goal):
    queue = deque([(start, [start])])
    seen = {start}
    visit_order = []

    print("\nBFS TRACE")
    while queue:
        node, path = queue.popleft()
        visit_order.append(node)
        print("Processed:", node, "| Queue:", [item[0] for item in queue])

        if node == goal:
            return path, visit_order

        for neighbour in graph[node]:
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append((neighbour, path + [neighbour]))

    return None, visit_order


def dfs(start, goal):
    stack = [(start, [start])]
    seen = set()
    visit_order = []

    print("\nDFS TRACE")
    while stack:
        node, path = stack.pop()

        if node in seen:
            continue

        seen.add(node)
        visit_order.append(node)
        print("Processed:", node, "| Stack:", [item[0] for item in stack])

        if node == goal:
            return path, visit_order

        # Reverse insertion makes DFS visit the first listed neighbour first.
        for neighbour in reversed(graph[node]):
            if neighbour not in seen:
                stack.append((neighbour, path + [neighbour]))

    return None, visit_order


bfs_path, bfs_order = bfs("A", "G")
dfs_path, dfs_order = dfs("A", "G")

print("\nFINAL RESULTS")
print("BFS path:", bfs_path)
print("BFS visit order:", bfs_order)
print("DFS path:", dfs_path)
print("DFS visit order:", dfs_order)
