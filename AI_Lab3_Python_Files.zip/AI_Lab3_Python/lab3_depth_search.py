# DLS and IDDFS for the original A-G graph.

graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": ["G"],
    "F": [],
    "G": []
}


def dls(node, goal, limit, path):
    if node == goal:
        return "FOUND", path

    # At the depth limit, check whether a deeper unvisited-in-this-path
    # option exists. If it does, the search was cut off.
    if len(path) - 1 == limit:
        for neighbour in graph[node]:
            if neighbour not in path:
                return "CUTOFF", None
        return "FAILURE", None

    got_cutoff = False

    for neighbour in graph[node]:
        # Path-local check prevents cycles without blocking other branches.
        if neighbour in path:
            continue

        status, result = dls(neighbour, goal, limit, path + [neighbour])

        if status == "FOUND":
            return status, result
        if status == "CUTOFF":
            got_cutoff = True

    if got_cutoff:
        return "CUTOFF", None
    return "FAILURE", None


def iddfs(start, goal, max_depth):
    print("\nIDDFS, maximum depth:", max_depth)
    for limit in range(max_depth + 1):
        status, path = dls(start, goal, limit, [start])
        print("Limit:", limit, "| Status:", status, "| Path:", path)
        if status == "FOUND":
            return path
        if status == "FAILURE":
            return None
    return None


print("DLS TESTS")
for limit in [1, 2, 3, 4]:
    status, path = dls("A", "G", limit, ["A"])
    print("Limit:", limit, "| Status:", status, "| Path:", path)

print("\nIDDFS TESTS")
for maximum in [1, 2, 3, 4]:
    iddfs("A", "G", maximum)
