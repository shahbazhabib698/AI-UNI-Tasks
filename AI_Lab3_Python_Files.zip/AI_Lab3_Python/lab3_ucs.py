import heapq

# Weighted extension of the original graph.
# Added corridor: C -> G. All costs are nonnegative.
weighted_graph = {
    "A": [("B", 1), ("C", 6)],
    "B": [("D", 2), ("E", 1)],
    "C": [("F", 2), ("G", 6)],
    "D": [],
    "E": [("G", 1)],
    "F": [],
    "G": []
}


def path_cost(path):
    total = 0
    for first, second in zip(path, path[1:]):
        for neighbour, cost in weighted_graph[first]:
            if neighbour == second:
                total += cost
                break
    return total


def bfs_weighted(start, goal):
    # BFS ignores weights and chooses the path with the fewest edges.
    queue = [(start, [start])]
    seen = {start}

    while queue:
        node, path = queue.pop(0)
        if node == goal:
            return path

        for neighbour, cost in weighted_graph[node]:
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append((neighbour, path + [neighbour]))

    return None


def ucs(start, goal):
    # Priority queue items: total cost, current node, path.
    frontier = [(0, start, [start])]
    best_cost = {start: 0}
    visit_order = []

    while frontier:
        cost_so_far, node, path = heapq.heappop(frontier)

        if cost_so_far > best_cost.get(node, float("inf")):
            continue

        visit_order.append(node)
        print("Processed:", node, "| Cost:", cost_so_far)

        if node == goal:
            return path, cost_so_far, visit_order

        for neighbour, edge_cost in weighted_graph[node]:
            new_cost = cost_so_far + edge_cost
            if new_cost < best_cost.get(neighbour, float("inf")):
                best_cost[neighbour] = new_cost
                heapq.heappush(frontier, (new_cost, neighbour, path + [neighbour]))

    return None, None, visit_order


bfs_path = bfs_weighted("A", "G")
ucs_path, ucs_cost, order = ucs("A", "G")

print("\nRESULTS")
print("Weighted edges:")
for node in weighted_graph:
    print(node, "->", weighted_graph[node])

print("\nBFS path:", bfs_path)
print("BFS hop count:", len(bfs_path) - 1 if bfs_path else "No path")
print("BFS total cost:", path_cost(bfs_path) if bfs_path else "No path")

print("\nUCS path:", ucs_path)
print("UCS total cost (reported):", ucs_cost)
print("UCS total cost (checked separately):", path_cost(ucs_path) if ucs_path else "No path")
print("UCS processing order:", order)
